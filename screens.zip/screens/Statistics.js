import React from 'react';
import {StyleSheet, View, Text, Dimensions, Alert } from 'react-native';
import {MaterialCommunityIcons, Ionicons, MaterialIcons, FontAwesome5} from '@expo/vector-icons'
import { FlatList } from 'react-native-gesture-handler';
import { category } from './config/rest_consfig';
import { Button } from 'react-native-paper';

const screenWidth = Dimensions.get('window').width

const LocationsAvoided = '0'

const RecordedComplaints = '0'

const HelpWarnings = 0

const PetitionsSigned = 1

const ComplaintsRead = 0

export default function App(props) {
    return (
        <View style={styles.container}>
            <Text style={{fontSize: 16, paddingLeft: 10, marginBottom: 5}}>Showing Results:   </Text>
            <View
            style={{
                borderTopWidth: 6,
                borderTopColor: '#fee11a',
                borderRadius: 3,
                width: 140,
            }}
            />
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000000'}}>Recorded Complaints in HEARD</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <Ionicons name="ios-people" size={30} color="#000000" style={{paddingRight: 5}}/>
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000000'}}>{RecordedComplaints}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000'}}>Petitions Signed</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <FontAwesome5 name="signature" size={24} color="#000" style={{paddingRight: 5}}/>
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000'}}>{PetitionsSigned}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000000'}}>Locations Avoided: </Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <MaterialIcons name="location-city" size={30} color="#000000" style={{paddingRight: 5}} />
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000000'}}>{LocationsAvoided}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000'}}>"Help" Warnings Sent</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <MaterialCommunityIcons name="exclamation" size={30} color="#000" style={{paddingRight: 5}}/>
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000'}}>{HelpWarnings}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000'}}>Complaints Read</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <MaterialCommunityIcons name="trending-up" size={30} color="#000" style={{paddingRight: 5}} />
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000'}}>{ComplaintsRead}</Text>
                </View>
            </View>
        </View>
    );
}


const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      paddingHorizontal: 10,
      padding: 15,
    },
});