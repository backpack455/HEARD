import React, { Component } from 'react';
import { Container, Header, Content, List, ListItem, Thumbnail, Text, Left, Body, Right, Button } from 'native-base';

import { Alert, View, ActivityIndicator, StatusBar, RefreshControl, ScrollView, StyleSheet, FlatList} from 'react-native';
import {DataItem} from './components/dataItemComplaints'
import Modal from './components/modal'
import ShowingTitle from './Showing'

console.disableYellowBox = true;
const wait = (timeout) => {
  return new Promise(resolve => {
    setTimeout(resolve, timeout);
  });
}

export default class ListThumbnailExample extends Component {
  constructor(props){
    super(props)

    this.state = {
      isLoading: true,
      data: null,
      setModalVisible: false,
      modalArticleData: {},
      refreshing: false,
      checkingForComplaints: 0,
    }
  }
  getData = () => {
    
  }
  // componentDidMount(){
  //   getArticles().then(data =>{
  //     this.setState({
  //       isLoading: false,
  //       data: data, 
  //     })
  //   }, error => {
  //     Alert.alert('Failure.', 'Please try again.')
  //   }
  //   )
  // }
  
  _onRefresh = () => {
    this.setState({refreshing: true});
    setTimeout(() => {
      // prepend 10 items
      let oldComplaints = this.state.checkingForComplaints 
      this.setState({
        checkingForComplaints: oldComplaints + 1,
        refreshing: false,
      });
    }, 2000);
  };

  
  render() {
    

    let view = this.state.checkingForComplaints < 2 ? (
      <View>
        {/* {
              this.state.refreshing && (<View style={{ flex: 1, paddingTop: 20 }}>
                <ActivityIndicator />
              </View>)} */}
         
        <Text style={{fontSize: 16, paddingLeft: 10, marginBottom: 10, paddingTop: 20}}>Latest Complaints:</Text>
        <View
          style={{
            borderTopWidth: 6,
            borderTopColor: '#fee11a',
            borderRadius: 3,
            width: 150,
            marginBottom: 10, 
            alignSelf: 'flex-start'
          }}
        /> 
        {/* <ActivityIndicator animating={this.state.isLoading}/> */}
        <Text style={{marginTop: 15, color: '#ff0000', fontWeight: 'bold', alignSelf: 'center'}}>No Complaints Found</Text>
      </View>
    ) : (
    <View>
      <Text style={{fontSize: 16, paddingLeft: 10, marginBottom: 10, paddingTop: 20}}>Latest Complaints:</Text>
        <View
          style={{
            borderTopWidth: 6,
            borderTopColor: '#fee11a',
            borderRadius: 3,
            width: 150,
            marginBottom: 10, 
            alignSelf: 'flex-start'
          }}
        />
      <List>
        <DataItem/>
      </List>
    </View>
    )
  

    return (
      <Container>
        <StatusBar barStyle="dark-content" translucent/>
        <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={this.state.refreshing}
            onRefresh={this._onRefresh}
            title="Getting Data..."
            progressBackgroundColor="#ffff00"
          />
        }
        >
          <Content>
            {view}
          </Content>
        </ScrollView>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: 'pink',
    alignItems: 'center',
    justifyContent: 'center',
  },
})