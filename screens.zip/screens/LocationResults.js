import React from 'react';
import {StyleSheet, View, Text, Dimensions, Alert } from 'react-native';
import {MaterialCommunityIcons, Ionicons, FontAwesome5} from '@expo/vector-icons'
import { FlatList } from 'react-native-gesture-handler';
import { category } from './config/rest_consfig';
import { Button } from 'react-native-paper';

const screenWidth = Dimensions.get('window').width

const RiskLevel = '1'

const RecordedPeople = '0'

const EstPeople = '(Est 0-5) '

const PIHS = 0

const CasesCount = '1'

export default function App(props) {
    return (
        <View style={styles.container}>
            <Text style={{fontSize: 16, paddingLeft: 10, marginBottom: 5}}>Showing Results:   </Text>
            <View
            style={{
                borderTopWidth: 6,
                borderTopColor: '#fee11a',
                borderRadius: 3,
                width: 140,
            }}
            />
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000000'}}>Number of Recorded Complaints in this City:</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <Ionicons name="ios-people" size={30} color="#000000" style={{paddingRight: 5}}/>
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000000'}}>{RecordedPeople}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000000'}}>Number of Estimated Complaints in this City:</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <Ionicons name="ios-people" size={30} color="#000000" style={{paddingRight: 5}}/>
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000000'}}>{EstPeople}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000000'}}>Risk Level at this Location: </Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <MaterialCommunityIcons name="hospital-box" size={24} color="#000000" style={{paddingRight: 5}} />
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000000'}}>{RiskLevel}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000'}}>People in "Help" Status in this City</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <MaterialCommunityIcons name="exclamation" size={24} color="#000" style={{paddingRight: 5}}/>
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000'}}>{PIHS}</Text>
                </View>
            </View>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a'}}>
                <Text style={{color: '#000'}}>HEARD Users in this City</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    <MaterialCommunityIcons name="chart-areaspline" size={24} color="#000" style={{paddingRight: 5}}/>
                    <Text></Text>
                    <Text style={{fontSize: 24, color: '#000'}}>{CasesCount}</Text>
                </View>
            </View>
        </View>
    );
}


const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      paddingHorizontal: 10,
      padding: 15,
    },
});