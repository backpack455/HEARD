import React from 'react';
import {StyleSheet, View, Text, TouchableOpacity, Dimensions, Image } from 'react-native';
import {Ionicons} from 'react-native-vector-icons'
const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const RiskLevel = '2-3'
const Victim = 'Om Joshi'
const Title = 'Cashier Refused To Offer Me Service At Kroger'
const Description = ''
const Location = 'Bloomfield Hills, Michigan'
const Date = '8/01/2020'
const Race = 'IDK'
const RaceOfVictimizer = 'IDK'
const Time = '6:53 PM'
const Victimizer = 'IDK'
const Profession = 'Cashier'

const ComplaintsRead = 1
export default class HomeScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
          <View style={styles.container}>
            <View style={{margin: 8, borderRadius: 20, paddingVertical: 20, paddingHorizontal: 24, width: (screenWidth-64/2), backgroundColor: '#fee11a', height:screenHeight - 300 }}>
                <Text style={{color: '#000000',fontSize:24 , fontWeight: 'bold'}}>{Title}</Text>
                <Text></Text>
                <View style={{flexDirection: 'row'}}>
                    
                    <Image style={styles.BorderClass}source={require('./../assets/OmJoshi.jpeg')}/>
                    <View style={{flexDirection: 'column'}}>
                        <Text style={styles.Text}>My name is {Victim}.</Text>
                        <Text/>
                        <Text style={styles.TextLittle}>I encountered an act of discrimination due {"\n"}to who I am. The following occurred:{"\n"}{"\n"}I went to Kroger and I was denied service {"\n"}by the cashier due to the apparent reason {"\n"}that it was due to my race.{Description} More {"\n"}information regarding this is below:</Text>
                    </View>
                </View>
                <View style={{flexDirection: 'row'}}>
                    <View style={{flexDirection: 'column'}}>
                        <Text/>
                        <Text/>
                        <Text style={styles.Text}>Location: {Location}</Text>
                        <Text/>
                        <Text style={styles.Text}>Time: {Time}</Text>
                        <Text/>
                        <Text style={styles.Text}>Date: {Date}</Text>
                        <Text/>
                        <Text style={styles.Text}>My Race/Ethnicity: {Race}</Text>
                        <Text/>
                        <Text style={styles.Text}>Victimizer: {Victimizer}</Text>
                        <Text/>
                        <Text style={styles.Text}>Race of Victimizer: {RaceOfVictimizer}</Text>
                        <Text/>
                        <Text style={styles.Text}>Profession: {Profession}</Text>
                        <Text/>
                    </View>
                </View>
            </View>
          </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    input: {
      height: 40,
      width: 300,
      paddingHorizontal: 5,
      backgroundColor: 'white',
      marginBottom: 5,
    },
    inputContainer: {
      marginBottom: 20,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.23,
      shadowRadius: 2.62,
      elevation: 4,
    },
    error: { textAlign: 'center', height: 17.5 },
    BorderClass:{
    height: 100,
    width: 100,
    // Set border width.
    borderWidth: 1,
    
    // Set border Hex Color code here.
    borderColor: '#fee11a',
    
    // Set border Radius.
    borderRadius: 10
    },
    Text : {
        paddingLeft: 10,
        fontSize: 20,
        flexDirection: 'column'
    },
    TextLittle: {
        paddingLeft: 10,
        fontSize: 12,
        alignSelf: 'flex-start'
    }
});