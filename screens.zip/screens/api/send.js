export const send = (email, password) => {
    return post('/users/login', {
      user: { email, password },
    });
  };