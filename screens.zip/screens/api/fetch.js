const formatResult = async (result) => {
    const formatted = {
      status: result.status,
      ok: result.ok,
    };
  
    if (result.ok) {
      formatted.data = await result.json()
    }
  
    return formatted;
};

export const post = async (destination, body) => {
    const headers = await getHeaders()
  
    const result = await fetch(`${API_URL}${destination}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    })
  
    const formattedResult = await formatResult(result);
    return formattedResult;
}