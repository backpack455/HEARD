import React, { useState } from 'react';
import {StyleSheet, Button, Text, TextInput, View } from 'react-native';

const getInitialState = (fieldKeys) => {
  const state = {};
  fieldKeys.forEach((key) => {
    state[key] = '';
  });

  return state;
};

const Form = ({ fields, buttonText, action}) => {
  const fieldKeys = Object.keys(fields);
  const [values, setValues] = useState(getInitialState(fieldKeys));
  const [errorMessage, setErrorMessage] = useState('');
  const onChangeValue = (key, value) => {
    const newState = { ...values, [key]: value };
    setValues(newState);
  };

  const getValues = () => {
    return fieldKeys.sort().map((key) => values[key]);
  };

  const submit = async () => {
    const values = getValues();
    try {
      const result = await action(...values);
      await afterSubmit(result)
    } catch(e) {
      console.log('error:', e)
    }
  };
  

  return (
    <View style={styles.container}>
        <Text>{errorMessage}</Text>
      {fieldKeys.map((key) => {
        const field = fields[key];
        return (
          <View key={key}>
            <Text>{field.label}</Text>
            <TextInput
              {...field.inputProps}
              value={values[key]}
              onChangeText={(text) => onChangeValue(key, text)}
            />
          </View>
        );
      })}
      <Button title={buttonText} onPress={submit} />
    </View>
  );
};
const styles = StyleSheet.create({
    container: {
      justifyContent: 'center',
      marginTop: 50,
      padding: 20,
      backgroundColor: '#ffffff',
    },
  });
export default Form;