import React, { Component } from 'react';
import { Container, Header, Content, List, ListItem, Thumbnail, Text, Left, Body, Right, Button } from 'native-base';
import {View} from 'react-native'
import * as WebBrowser from 'expo-web-browser'
import { useLinking } from '@react-navigation/native';

export default class ListThumbnailExample extends Component {
  render() {
    return (
      <Container>
        <Content>
          <List>
            <ListItem thumbnail>
              <Left>
                <Thumbnail square source={{ uri: 'https://assets.change.org/photos/0/la/lt/mylaLTYqhScqWHI-800x450-noPad.jpg' }} />
              </Left>
              <Body>
                <Text>Justice for George Floyd Petition</Text>
                <Text note numberOfLines={3}>George was handcuffed and restrained and being completely cooperative when this all went down. The officer put his knee on George’s neck choking him for minutes on minutes while George screamed that he could not breathe. Bystanders beg for the police officer to take his knee off George’s neck, but the officer didn’t listen and continued to choke him.</Text>
                <View style={{flex: 1, flexDirection: 'row', marginTop: 8, marginLeft: 0 }}>
                    <Text note>Change.org</Text>
                </View>
              </Body>
              <Right>
                <Button transparent onPress={() => WebBrowser.openBrowserAsync('http://chng.it/Rtpbxv2CdK')}>
                  <Text>Read</Text>
                </Button>
              </Right>
              
            </ListItem>
            <ListItem thumbnail>
              <Left>
                <Thumbnail square source={{ uri: 'https://images.squarespace-cdn.com/content/v1/5ea8571672dca4690a8ce567/1588179103713-1V14BJ20H3K2U4F31SRY/ke17ZwdGBToddI8pDm48kKOdTmj2ye5Yr55kbAAPV5ZZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZUJFbgE-7XRK3dMEBRBhUpywO_rJqxklusn2SZjK8CZ8tB9GFIpA8pJgN_u7s1jYHC_JBhTJGCSmexuY0Mf12EY/ahmaud+tux+reg.jpg' }} />
              </Left>
              <Body>
                <Text>Justice for Armaud Arbery Petition</Text>
                <Text note numberOfLines={3}>Ahmaud Arbery, a fit athlete, was out jogging near his home on a Sunday afternoon in Brunswick, Georgia on February 23, 2020, when two white supremacists saw him, got their guns, got in a truck, chased him down, pulled up next to him, shot him at least two times, and killed him right there on the spot. Ahmaud was unarmed, broke no laws, and did nothing wrong. He was only 25 years old when he died.</Text>
                <View style={{flex: 1, flexDirection: 'row', marginTop: 8, marginLeft: 0 }}>
                    <Text note>The Action PAC</Text>
                </View>
              </Body>
              <Right>
                <Button transparent onPress={() => WebBrowser.openBrowserAsync('https://www.runwithmaud.com/')}>
                  <Text>Read</Text>
                </Button>
              </Right>
              
            </ListItem>
            <ListItem thumbnail>
              <Left>
                <Thumbnail square source={{ uri: 'https://assets.change.org/photos/5/tg/gk/uNtGGkZoxgRnuuz-800x450-noPad.jpg' }} />
              </Left>
              <Body>
                <Text>Justice for Breonna Taylor Petition</Text>
                <Text note numberOfLines={3}>Nearly four months ago, a division of the Louisville Police Department performed an illegal, unannounced drug raid on her home. Not a single officer announced themselves before ramming down her door and firing 22 shots, shooting Breonna 8 times, killing her. </Text>
                <View style={{flex: 1, flexDirection: 'row', marginTop: 8, marginLeft: 0 }}>
                    <Text note>Change.org</Text>
                </View>
              </Body>
              <Right>
                <Button transparent onPress={() => WebBrowser.openBrowserAsync('https://www.change.org/p/andy-beshear-justice-for-breonna-taylor/psf/promote_or_share?recruiter=')}>
                  <Text>Read</Text>
                </Button>
              </Right>
              
            </ListItem>
            <ListItem thumbnail>
              <Left>
                <Thumbnail square source={{ uri: 'https://assets.change.org/photos/5/iw/ta/hGIWtaAaRuIKGJv-800x450-noPad.jpg' }} />
              </Left>
              <Body>
                <Text>Justice for Tony McDade Petition</Text>
                <Text note numberOfLines={3}>Tony McDade was a transgender black man who got killed by police in Tallahassee. As of right now I haven’t seen many people talking about this, but I would really like to get his name out there. It would be very appreciated if you could sign this petition and encourage others to do so as well. </Text>
                <View style={{flex: 1, flexDirection: 'row', marginTop: 8, marginLeft: 0 }}>
                    <Text note>Change.org</Text>
                </View>
              </Body>
              <Right>
                <Button transparent onPress={() => WebBrowser.openBrowserAsync('https://www.change.org/p/black-lives-matter-activists-justice-for-tony-mcdade')}>
                  <Text>Read</Text>
                </Button>
              </Right>
              
            </ListItem>
            <ListItem thumbnail>
              <Left>
                <Thumbnail square source={{ uri: 'https://assets.change.org/photos/8/tj/jv/EYtjJVxvFfPTsDw-800x450-noPad.jpg' }} />
              </Left>
              <Body>
                <Text>Hands Up Act Petiton</Text>
                <Text note numberOfLines={3}>My name is Travis Washington. I received my M. A, degree in Higher Education and Administration from Southern Illinois University Carbondale in May 2019. I have been politically involved, from registering people to vote, to work in the Springfield Capitol (as an Alexander Lane Fellow, January to May 2017).</Text>
                <View style={{flex: 1, flexDirection: 'row', marginTop: 8, marginLeft: 0 }}>
                    <Text note>Change.org</Text>
                </View>
              </Body>
              <Right>
                <Button transparent onPress={() => WebBrowser.openBrowserAsync('https://www.change.org/p/us-senate-hands-up-act')}>
                  <Text>Read</Text>
                </Button>
              </Right>
              
            </ListItem>
            
          </List>
        </Content>
      </Container>
    );
  }
}